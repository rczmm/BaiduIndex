from qdata.baidu_login import get_cookie_by_qr_login

if __name__ == "__main__":
    print(get_cookie_by_qr_login())
